package nl.smeetsm.bean;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.util.HashMap;

import javax.jms.Connection;
import javax.jms.ObjectMessage;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;

public class BPELBean implements BPELBeanInterface {
    public BPELBean() {
        super();
    }

    public String putMessageOnQueue(String queue, String connFact,
                                    String message, Long delay,
                                    HashMap<String, JMSPropertyValue> JMSProperties) {
        try {
            javax.naming.Context ctx = new javax.naming.InitialContext();
            javax.jms.Destination JMSDestination =
                (javax.jms.Destination)ctx.lookup(queue);
            javax.jms.ConnectionFactory confact =
                (javax.jms.ConnectionFactory)ctx.lookup(connFact);
            Connection tCon = confact.createConnection();
            Session session =
                tCon.createSession(false, Session.AUTO_ACKNOWLEDGE);
            weblogic.jms.extensions.WLMessageProducer producer =
                (weblogic.jms.extensions.WLMessageProducer)session.createProducer(JMSDestination);
            producer.setTimeToDeliver(delay);
            javax.jms.TextMessage msg = session.createTextMessage();
            msg.setText(message);

            JMSPropertyValue property;

            if (JMSProperties != null) {
                for (String key : JMSProperties.keySet()) {
                    property = JMSProperties.get(key);
                    if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.STRING)) {
                        msg.setStringProperty(key,
                                              JMSProperties.get(key).getValue());
                    } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.INT)) {
                        msg.setIntProperty(key,
                                           Integer.parseInt(JMSProperties.get(key).getValue()));
                    } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.BOOLEAN)) {
                        msg.setBooleanProperty(key,
                                               Boolean.parseBoolean(JMSProperties.get(key).getValue()));
                    } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.FLOAT)) {
                        msg.setFloatProperty(key,
                                             Float.parseFloat(JMSProperties.get(key).getValue()));
                    } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.LONG)) {
                        msg.setLongProperty(key,
                                            Long.parseLong(JMSProperties.get(key).getValue()));
                    } else if (property.getJmspropertytype().equals(JMSPropertyValue.JMSPROPERTYTYPE.DOUBLE)) {
                        msg.setDoubleProperty(key,
                                              Double.parseDouble(JMSProperties.get(key).getValue()));
                    }
                }
            }

            producer.send(msg);
        } catch (Throwable e) {
            StringWriter errors = new StringWriter();
            e.printStackTrace(new PrintWriter(errors));
            return "NOK: " + errors.toString();
        }
        return "OK";
    }
}
