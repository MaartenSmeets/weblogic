package nl.smeetsm.bean;

import java.util.HashMap;

public interface BPELBeanInterface {
    public String putMessageOnQueue(String queue,String ConnFact,String message,Long delay, HashMap<String, JMSPropertyValue> JMSProperties);
}
